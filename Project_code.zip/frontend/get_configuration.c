#ifndef _WIN32
  #include <sys/socket.h>

  #include <arpa/inet.h>
  #include <netinet/in.h>
#endif

#include <string.h>

#include <ulfius.h>

#include "cJSON.h"

#include "stdlib.h"

#include "u_example.h"


#define PORT 8080
#define FILENAME "data.json"
#define PREFIX "/dummy/api"

int callback_put_data(const struct _u_request *request, struct _u_response *response, void *user_data);
int callback_get_data(const struct _u_request *request, struct _u_response *response, void *user_data);


int main(int argc, char **argv) {
  struct _u_instance instance;
  if (ulfius_init_instance(&instance, PORT, NULL, NULL) != U_OK) {
    fprintf(stderr, "Error initializing ulfius\n");
    exit(EXIT_FAILURE);
  }

  ulfius_add_endpoint_by_val(&instance, "PUT", PREFIX ,"/data", 0, &callback_put_data, NULL);
  ulfius_add_endpoint_by_val(&instance, "GET","get/data", NULL, 0, &callback_get_data, NULL);

  if (ulfius_start_framework(&instance) == U_OK) {
    printf("Server started on port %d\n", instance.port);
    getchar();
  } else {
    fprintf(stderr, "Error starting framework\n");
  }

  printf("Stopping server...\n");
  ulfius_stop_framework(&instance);
  ulfius_clean_instance(&instance);

  return 0;
}

int callback_put_data(const struct _u_request *request, struct _u_response *response, void *user_data)
{

   // Parse binary data as a JSON string
   char *json_str = malloc(request->binary_body_length + 1);
   memset(json_str, 0, request->binary_body_length + 1);
   memcpy(json_str, request->binary_body, request->binary_body_length);
   json_str[request->binary_body_length + 1] = '\0';

   // Parse the JSON string using cjson library
   cJSON *json_root = cJSON_Parse(json_str);

   if (json_root == NULL)
   {
      // If there is an error in parsing JSON, return error response to client
      ulfius_set_string_body_response(response, 400, "Invalid JSON body");
      return U_CALLBACK_CONTINUE;
   }

   // Access JSON key-value pairs

   cJSON *device_id = cJSON_GetObjectItemCaseSensitive(json_root, "device_id");
   cJSON *device_name = cJSON_GetObjectItemCaseSensitive(json_root, "sourceId");
   
   //////Subobject payload
    cJSON *sensors = cJSON_GetObjectItemCaseSensitive(json_root, "sensors");
    int arr1_size = cJSON_GetArraySize(sensors);

    ///////// Getting array items
   for (int i = 0; i < arr1_size; i++){
    cJSON *subitem = cJSON_GetArrayItem(sensors, i);

      cJSON *sensor_id = cJSON_GetObjectItemCaseSensitive(subitem, "sensor_id");
      cJSON *sensor_type = cJSON_GetObjectItemCaseSensitive(subitem, "sensor_type");
      ////// getting the data object values
      cJSON *data = cJSON_GetObjectItemCaseSensitive(subitem, "data");
      cJSON *value = cJSON_GetObjectItemCaseSensitive(data, "value");
      cJSON *units = cJSON_GetObjectItemCaseSensitive(data, "units");
   } 

   /////// Getting settings values
   cJSON *settings = cJSON_GetObjectItemCaseSensitive(json_root, "settings");
   cJSON *temperature = cJSON_GetObjectItemCaseSensitive(settings, "temperature");
      ////// getting the data object values
      cJSON *target = cJSON_GetObjectItemCaseSensitive(temperature, "target");
      cJSON *range = cJSON_GetObjectItemCaseSensitive(temperature, "range");
      cJSON *notifications = cJSON_GetObjectItemCaseSensitive(temperature, "notifications");

/////////// Getting values of metadata
cJSON *metadata = cJSON_GetObjectItemCaseSensitive(json_root, "metadata");
   cJSON *location = cJSON_GetObjectItemCaseSensitive(metadata, "location");
      ////// getting the data object values
      cJSON *lat = cJSON_GetObjectItemCaseSensitive(location, "lat");
      cJSON *longt = cJSON_GetObjectItemCaseSensitive(location, "longt");
      
      cJSON *room = cJSON_GetObjectItemCaseSensitive(metadata, "room");

   char *response_str = cJSON_Print(json_root);

   FILE *fp = fopen(FILENAME, "w");

   if (fp == NULL)
   {
      printf("Error in fp creation\n");
      return 1;
   }

   fprintf(fp, "%s\n", response_str);
   fclose(fp);

   if (strcmp(json_str, response_str))
   {
      printf("Both are same \r\n");
   }
   printf("%s", response_str);

   // Free cJSON object
   free(json_str);
   cJSON_Delete(json_root);

   // Return success response to client
   ulfius_set_string_body_response(response, 200, response_str);
   fflush(stdout);
   return U_CALLBACK_CONTINUE;
}

int callback_get_data(const struct _u_request *request, struct _u_response *response, void *user_data)
{
    FILE *fp = fopen(FILENAME , "r");
    if (fp == NULL)
    {
        printf("Error opening file\n");
        return 1;
    }

    // Get file length
    fseek(fp, 0, SEEK_END);
    long length = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    // Allocate buffer and read file contents
    char *buffer = malloc(length + 1);
    memset(buffer, 0, length + 1);
    fread(buffer, 1, length, fp);

    fclose(fp);

    // Set response body to file contents
    ulfius_set_string_body_response(response, 200, buffer);

    free(buffer);
    return U_CALLBACK_CONTINUE;
}


